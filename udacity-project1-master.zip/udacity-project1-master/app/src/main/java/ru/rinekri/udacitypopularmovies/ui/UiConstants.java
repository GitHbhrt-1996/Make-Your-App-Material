package ru.rinekri.udacitypopularmovies.ui;

public class UiConstants {
  public static final Integer GRID_COLUMNS = 2;
  public static int BLUR_RADIUS = 10;
}
