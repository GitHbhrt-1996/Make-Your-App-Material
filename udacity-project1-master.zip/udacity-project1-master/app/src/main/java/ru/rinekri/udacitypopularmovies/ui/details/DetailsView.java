package ru.rinekri.udacitypopularmovies.ui.details;

import ru.rinekri.udacitypopularmovies.ui.base.BaseMvpView;

public interface DetailsView extends BaseMvpView<DetailsPM> {}