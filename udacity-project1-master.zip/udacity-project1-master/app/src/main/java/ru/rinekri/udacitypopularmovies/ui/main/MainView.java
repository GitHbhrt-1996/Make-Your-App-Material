package ru.rinekri.udacitypopularmovies.ui.main;

import ru.rinekri.udacitypopularmovies.ui.base.BaseMvpView;

public interface MainView extends BaseMvpView<MainPM> {
  void showInitContent(MainIM data);
}